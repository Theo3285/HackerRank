package com.hackerrank;

enum Color {
    RED, GREEN
}
