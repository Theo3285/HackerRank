package com.hackerrank;

public class Console {
    public void printLine(String s) {
        System.out.println(s);
    }
}
